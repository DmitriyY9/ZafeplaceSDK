//
//  CreatePassiveSellOfferOperation.swift
//  stellarsdk
//
//  Created by Christian Rogobete on 06.05.19.
//  Copyright © 2019 Soneso. All rights reserved.
//

import Foundation

public class CreatePassiveSellOfferOperation:CreatePassiveOfferOperation {
    
}
