//
//  stellarsdk_macOS.h
//  stellarsdk-macOS
//
//  Created by Razvan Chelemen on 29/01/2018.
//  Copyright © 2018 Soneso. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for stellarsdk_macOS.
FOUNDATION_EXPORT double stellarsdk_macOSVersionNumber;

//! Project version string for stellarsdk_macOS.
FOUNDATION_EXPORT const unsigned char stellarsdk_macOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <stellarsdk_macOS/PublicHeader.h>


