//
//  web3swift.h
//  web3swift
//
//  Created by Sameer Khavanekar on 1/18/18.
//  Copyright © 2018 Radical App LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for web3swift.
FOUNDATION_EXPORT double web3swiftVersionNumber;

//! Project version string for web3swift.
FOUNDATION_EXPORT const unsigned char web3swiftVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <web3swift/PublicHeader.h>


