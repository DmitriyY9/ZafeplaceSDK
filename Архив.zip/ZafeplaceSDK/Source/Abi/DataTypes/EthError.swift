//
//  EthError.swift
//  Dust
//
//  Created by Sameer Khavanekar on 1/16/18.
//  Copyright © 2018 Radical App LLC. All rights reserved.
//

import Foundation


enum EthError: Error {
    case typeCanNotBeEncoded
}
